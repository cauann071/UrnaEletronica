package br.com.poo.modelo;

public class Partido {
    
}
