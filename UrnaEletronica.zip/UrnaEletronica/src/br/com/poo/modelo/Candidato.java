package br.com.poo.modelo;


public class Candidato {
    private String nome;
    private String sigla;
    private int numero;
    
    public Candidato(){
        this.nome = nome;
        this.numero = numero;
        this.sigla = sigla;
    }
}
